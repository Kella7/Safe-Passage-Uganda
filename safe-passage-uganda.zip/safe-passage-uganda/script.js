// SAFEKAZI SCRIPT.JS - every part is small and independent
function $(id) { return document.getElementById(id); }

// A. Page change: shrink the sheet into a tile, then open the new page
function go(url) {
  var sheet = document.querySelector(".sheet");
  sheet.classList.add("leave");
  setTimeout(function () {
    if (window.SK_NAV) { window.SK_NAV(url); } else { window.location.href = url; }
  }, 380);
}
// One click listener for the menu button and for every internal link
document.addEventListener("click", function (e) {
  var btn = e.target.closest("#menu-btn");
  if (btn) {
    var open = $("menu").classList.toggle("open");
    btn.setAttribute("aria-expanded", open);
    return;
  }
  if (e.target.closest(".ask-open,#ask-btn")) { e.preventDefault(); toggleAsk(); return; }
  if (e.target.closest("#ask-close")) { toggleAsk(false); return; }
  var a = e.target.closest("a");
  if (!a) return;
  var h = a.getAttribute("href");
  if (!h || h.charAt(0) === "#" || /^(https?:|mailto:|tel:)/.test(h)) return;
  e.preventDefault();
  go(h);
});

// B. Everything that must start when a page is shown
function init() {
  reveal(); counters(); verify(); flags(); report(); help(); assistant(); stamps();
  if (window.initGlobe && $("globe")) { initGlobe(); }
}

// C. Reveal: add class "in" when an element scrolls into view (CSS does the animation)
function reveal() {
  var io = new IntersectionObserver(function (list) {
    list.forEach(function (e) {
      if (e.isIntersecting) { e.target.classList.add("in"); io.unobserve(e.target); }
    });
  }, { threshold: 0.12 });
  document.querySelectorAll(".reveal").forEach(function (el) { io.observe(el); });
}

// D. Count-up numbers (reads data-count, data-prefix, data-suffix, data-dec)
function counters() {
  var co = new IntersectionObserver(function (list) {
    list.forEach(function (e) {
      if (!e.isIntersecting) return;
      var n = e.target, to = +n.dataset.count, dec = +(n.dataset.dec || 0);
      var pre = n.dataset.prefix || "", suf = n.dataset.suffix || "", t0 = null;
      function step(t) {
        t0 = t0 || t;
        var k = Math.min((t - t0) / 1600, 1), v = to * (1 - Math.pow(1 - k, 3));
        n.textContent = pre + v.toLocaleString("en", { minimumFractionDigits: dec, maximumFractionDigits: dec }) + suf;
        if (k < 1) requestAnimationFrame(step);
      }
      requestAnimationFrame(step);
      co.unobserve(n);
    });
  });
  document.querySelectorAll("[data-count]").forEach(function (n) { co.observe(n); });
}

// E. Verify page: show what to compare in the official register
function verify() {
  var f = $("verify-form"); if (!f) return;
  f.addEventListener("submit", function (e) {
    e.preventDefault();
    var name = $("agency-name").value.trim(), out = $("verify-out");
    if (!name) { out.textContent = "Please type the agency name first."; return; }
    var steps = [
      "Exact legal name: compare the spelling of \u201C" + name + "\u201D with your documents and adverts.",
      "Licence status and dates: read the current status and validity dates.",
      "Contact details: compare the official address and phone numbers.",
      "Job approval: ask whether the vacancy and the employer have approval."];
    out.textContent = "";
    var ol = document.createElement("ol");
    steps.forEach(function (s) { var li = document.createElement("li"); li.textContent = s; ol.appendChild(li); });
    out.appendChild(ol);
    var p = document.createElement("p");
    p.textContent = "If you cannot confirm the agency, treat it as not verified. Missing from a search is not proof of fraud.";
    out.appendChild(p);
  });
}

// F. Red flags: count the ticks and give advice
function flags() {
  var f = $("flag-form"); if (!f) return;
  $("flag-review").onclick = function () {
    var n = f.querySelectorAll("input:checked").length, out = $("flag-out"), msg;
    if (n === 0) msg = "No warning signs ticked. Keep checking the agency in the official register.";
    else if (n < 3) msg = n + " warning sign(s). Pause, ask questions and verify independently before you pay.";
    else msg = n + " warning signs. Strong caution: do not pay or hand over documents until you have verified the agency.";
    out.textContent = msg;
    out.className = "note" + (n >= 3 ? " warn" : "");
  };
  $("flag-clear").onclick = function () { f.reset(); $("flag-out").textContent = ""; };
}

// G. Report: prepare notes in the browser (nothing is sent or stored)
function report() {
  var f = $("report-form"); if (!f) return;
  f.addEventListener("submit", function (e) {
    e.preventDefault();
    $("report-out").textContent = "Agency: " + (f.agency.value || "not given") + "\nWhere: " + f.where.value +
      "\nConcern: " + f.concern.value + "\nWhat happened: " + (f.story.value || "not given");
    $("report-copy").hidden = false;
  });
  $("report-copy").onclick = function () {
    if (navigator.clipboard) { navigator.clipboard.writeText($("report-out").textContent); this.textContent = "Copied"; }
  };
}

// H. Help: prepare a WhatsApp message for a trusted contact, with optional location
function help() {
  var f = $("wa-form"); if (!f) return;
  f.addEventListener("submit", function (e) {
    e.preventDefault();
    var num = $("wa-number").value.replace(/\D/g, ""), out = $("wa-out");
    if (num.length < 9) { out.textContent = "Enter the WhatsApp number with country code, for example 2567..."; return; }
    function openWa(loc) {
      var text = $("wa-text").value + (loc ? "\nMy location: " + loc : "");
      window.location.href = "https://wa.me/" + num + "?text=" + encodeURIComponent(text);
    }
    if ($("wa-loc").checked && navigator.geolocation) {
      out.textContent = "Finding your location...";
      navigator.geolocation.getCurrentPosition(function (p) {
        openWa("https://maps.google.com/?q=" + p.coords.latitude + "," + p.coords.longitude);
      }, function () { openWa(""); });
    } else { openWa(""); }
  });
}

// I. Assistant: a guided conversation. Tap an option and the chat continues in that direction.
// Languages: 0 English, 1 Luganda, 2 Kiswahili, 3 Arabic. Each text below is [en, lg, sw, ar].
var LANGS = ["English", "Luganda", "Kiswahili", "العربية"], LANG = 0, NUM = "", STATE = "";
var S = {
  ask: ["What do you need help with?", "Nkuyambe ntya?", "Unahitaji msaada gani?", "بماذا تحتاج المساعدة؟"],
  o_agency: ["Check an agency", "Kebera kampuni", "Kagua wakala", "التحقق من وكالة"],
  o_scam: ["I think it is a scam", "Ndowooza bufere", "Nadhani ni ulaghai", "أظن أنه احتيال"],
  o_rights: ["Contract and rights", "Endagaano n'eddembe", "Mkataba na haki", "العقد والحقوق"],
  o_abroad: ["I need help abroad", "Neetaaga obuyambi nga ndi mu nsi endala", "Nahitaji msaada nikiwa nje ya nchi", "أحتاج مساعدة وأنا في الخارج"],
  o_back: ["Back to start", "Ddayo ku ntandikwa", "Rudi mwanzo", "العودة للبداية"],
  o_yes: ["Yes", "Ye", "Ndiyo", "نعم"], o_no: ["No", "Nedda", "Hapana", "لا"],
  o_reg: ["Open the official register", "Ggulawo lisiti ya gavumenti", "Fungua orodha rasmi", "افتح السجل الرسمي"],
  o_verify: ["Use the Verify page", "Kozesa ekitundu kya Verify", "Tumia ukurasa wa Kukagua", "استخدم صفحة التحقق"],
  o_notes: ["Prepare my notes", "Teekateeka ebiwandiiko byange", "Andaa maelezo yangu", "جهّز ملاحظاتي"],
  o_flags: ["Open Red flags", "Ggulawo Red flags", "Fungua Alama Hatari", "افتح العلامات الحمراء"],
  o_rp: ["Open Your rights", "Ggulawo Your rights", "Fungua Haki zako", "افتح حقوقك"],
  o_send: ["Send a distress message", "Tuma obubaka bw'obuyambi", "Tuma ujumbe wa dharura", "أرسل رسالة استغاثة"],
  o_help: ["Open the Get help page", "Ggulawo Get help", "Fungua ukurasa wa Msaada", "افتح صفحة المساعدة"],
  a_agency: ["Compare the agency's name, licence and dates in the Ministry's official register. Do not pay before you have checked.", "Geraageranya erinnya lya kampuni, layisinsi n'ennaku ku lisiti ya gavumenti. Tosasula nga tonnakebera.", "Linganisha jina la wakala, leseni na tarehe kwenye orodha rasmi ya Wizara. Usilipe kabla ya kukagua.", "قارن اسم الوكالة والترخيص والتواريخ في سجل الوزارة الرسمي. لا تدفع قبل أن تتحقق."],
  a_scam: ["Warning signs: pressure to pay fast, no written contract, details that keep changing. Have you already paid money?", "Obubonero: okukukaka okusasula amangu, tewali ndagaano mu buwandiike, ebikwata ku mulimu bikyukakyuka. Wasasuddeko ssente?", "Dalili za hatari: shinikizo la kulipa haraka, hakuna mkataba ulioandikwa, maelezo yanayobadilika. Je, umeshalipa pesa?", "علامات الخطر: ضغط للدفع بسرعة، لا عقد مكتوب، تفاصيل تتغير. هل دفعت مالاً بالفعل؟"],
  a_paid: ["Keep every receipt and message. Report it to the Ministry or the police. I can help you prepare notes.", "Kuuma buli risiiti n'obubaka. Tegeeza Minisitule oba poliisi. Nsobola okukuyamba okuteekateeka ebiwandiiko.", "Hifadhi kila risiti na ujumbe. Ripoti kwa Wizara au polisi. Naweza kukusaidia kuandaa maelezo.", "احتفظ بكل إيصال ورسالة. بلّغ الوزارة أو الشرطة. يمكنني مساعدتك في تجهيز الملاحظات."],
  a_nopay: ["Good. Tick the warning signs on the Red flags page, and do not pay until the agency is verified.", "Kirungi. Laba obubonero ku Red flags, era tosasula okutuusa nga kampuni ekeberebbwa.", "Vizuri. Angalia dalili kwenye ukurasa wa Alama Hatari, na usilipe hadi wakala athibitishwe.", "جيد. حدّد علامات الخطر في صفحة العلامات الحمراء، ولا تدفع حتى يتم التحقق من الوكالة."],
  a_rights: ["Before you go, get a written contract naming the employer, job, salary, hours, housing and return travel. Keep your own passport.", "Nga tonnagenda, funa endagaano mu buwandiike eraga omukozesa, omulimu, omusaala, essaawa, ennyumba n'okudda. Kuuma pasipooti yo wekka.", "Kabla ya kusafiri, pata mkataba ulioandikwa unaotaja mwajiri, kazi, mshahara, saa za kazi, makazi na nauli ya kurudi. Weka pasipoti yako mwenyewe.", "قبل السفر، احصل على عقد مكتوب يذكر صاحب العمل والوظيفة والراتب وساعات العمل والسكن وتذكرة العودة. احتفظ بجواز سفرك بنفسك."],
  a_danger: ["Are you in immediate danger?", "Oli mu kabi kaamu kaakano?", "Uko hatarini sasa hivi?", "هل أنت في خطر مباشر الآن؟"],
  a_emerg: ["Please contact local emergency services first. I can also send a distress message to someone you trust.", "Sooka okuyita obuyambi bw'ensi eyo. Nsobola n'okutumira omuntu gwe weesiga obubaka bw'obuyambi.", "Tafadhali wasiliana kwanza na huduma za dharura za eneo lako. Naweza pia kutuma ujumbe wa dharura kwa mtu unayemwamini.", "يرجى الاتصال بخدمات الطوارئ المحلية أولاً. يمكنني أيضاً إرسال رسالة استغاثة لشخص تثق به."],
  a_trouble: ["Keep copies of your documents and messages, tell someone you trust, and contact the Ministry or the Ugandan embassy. I can message your trusted person now.", "Kuuma kkopi z'ebiwandiiko n'obubaka, tegeeza gwe weesiga, era laga Minisitule oba ambasade ya Uganda. Nsobola okutumira gwe weesiga obubaka kati.", "Hifadhi nakala za nyaraka na ujumbe, mwambie mtu unayemwamini, na wasiliana na Wizara au ubalozi wa Uganda. Naweza kumtumia ujumbe sasa.", "احتفظ بنسخ من وثائقك ورسائلك، وأخبر شخصاً تثق به، وتواصل مع الوزارة أو سفارة أوغندا. يمكنني مراسلة الشخص الموثوق الآن."],
  q_num: ["Type your trusted person's WhatsApp number with country code, for example 2567...", "Wandiika ennamba ya WhatsApp ey'oyo gwe weesiga n'ennamba y'ensi, okugeza 2567...", "Andika namba ya WhatsApp ya mtu unayemwamini pamoja na msimbo wa nchi, mfano 2567...", "اكتب رقم واتساب للشخص الموثوق مع رمز الدولة، مثال 2567..."],
  q_loc: ["Include your location in the message?", "Teekamu ekifo kyo mu bubaka?", "Jumuisha eneo lako kwenye ujumbe?", "هل تضيف موقعك إلى الرسالة؟"],
  q_bad: ["That number looks too short. Please try again.", "Ennamba eyo ntono nnyo. Gezaako nate.", "Namba hiyo ni fupi sana. Jaribu tena.", "الرقم قصير جداً. حاول مرة أخرى."],
  done: ["Opening WhatsApp. Check the message, then press Send.", "Nguggulawo WhatsApp. Kebera obubaka, olwo ofuuyeko Send.", "Napofungua WhatsApp. Kagua ujumbe, kisha bonyeza Tuma.", "جارٍ فتح واتساب. راجع الرسالة ثم اضغط إرسال."],
  msg: ["EMERGENCY: I need help. Please contact me now.", "OBUYAMBI OBW'ANGWA: Neetaaga obuyambi. Nkwegayirira onkubire kati.", "DHARURA: Nahitaji msaada. Tafadhali nipigie sasa.", "طوارئ: أحتاج مساعدة. يرجى التواصل معي الآن."],
  free: ["I did not understand. Please choose an option.", "Simanyi bulungi. Londa emu ku zino.", "Sijaelewa. Tafadhali chagua chaguo.", "لم أفهم. يرجى اختيار أحد الخيارات."]
};
function tx(k) { return S[k][LANG]; }
function assistant() {
  var form = $("chat-form"); if (!form || form.dataset.ready) return;
  form.dataset.ready = "1";
  var box = $("chat"), chips = $("chips"), input = $("chat-input");
  var VOICE = ["en-UG", "en-UG", "sw-KE", "ar-SA"];
  function add(t, me) {                                   // draw one message bubble
    var d = document.createElement("div");
    d.className = "msg" + (me ? " me" : ""); d.textContent = t;
    box.appendChild(d); box.scrollTop = box.scrollHeight;
  }
  function say(t) {                                       // assistant speaks (and reads aloud if ticked)
    add(t, false);
    if ($("chat-speak").checked && window.speechSynthesis) {
      var u = new SpeechSynthesisUtterance(t); u.lang = VOICE[LANG]; speechSynthesis.speak(u);
    }
  }
  function show(opts) {                                   // draw tap buttons: [label, function to run]
    chips.textContent = "";
    opts.forEach(function (o) {
      var b = document.createElement("button");
      b.type = "button"; b.className = "chip"; b.textContent = o[0];
      b.onclick = function () { add(o[0], true); o[1](); };
      chips.appendChild(b);
    });
  }
  function link(u) { return function () { window.open(u, "_blank", "noopener"); }; }
  function page(u) { return function () { go(u); }; }
  function back() { return [tx("o_back"), menu]; }
  // The conversation: each function says something, then offers the next taps
  function menu() { STATE = ""; say(tx("ask")); show([[tx("o_agency"), agency], [tx("o_scam"), scam], [tx("o_rights"), rights], [tx("o_abroad"), abroad]]); }
  function agency() { say(tx("a_agency")); show([[tx("o_reg"), link("https://eemis.mglsd.go.ug/companies")], [tx("o_verify"), page("verify.html")], back()]); }
  function scam() { say(tx("a_scam")); show([[tx("o_yes"), paid], [tx("o_no"), nopay]]); }
  function paid() { say(tx("a_paid")); show([[tx("o_notes"), page("report.html")], back()]); }
  function nopay() { say(tx("a_nopay")); show([[tx("o_flags"), page("flags.html")], back()]); }
  function rights() { say(tx("a_rights")); show([[tx("o_rp"), page("rights.html")], back()]); }
  function abroad() { say(tx("a_danger")); show([[tx("o_yes"), function () { say(tx("a_emerg")); helpMenu(); }], [tx("o_no"), function () { say(tx("a_trouble")); helpMenu(); }]]); }
  function helpMenu() { show([[tx("o_send"), askNumber], [tx("o_help"), page("help.html")], back()]); }
  function askNumber() { STATE = "num"; chips.textContent = ""; say(tx("q_num")); input.focus(); }
  function send(withLoc) {                                // open WhatsApp with the distress message
    function open(loc) {
      var text = tx("msg") + (loc ? "\n" + loc : "");
      say(tx("done"));
      setTimeout(function () { window.location.href = "https://wa.me/" + NUM + "?text=" + encodeURIComponent(text); }, 900);
    }
    if (withLoc && navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(function (p) { open("https://maps.google.com/?q=" + p.coords.latitude + "," + p.coords.longitude); }, function () { open(""); });
    } else { open(""); }
  }
  // First thing a visitor sees: choose a language
  window.startChat = function () {
    if (box.children.length) return;
    add("Hello · Oli otya · Habari · مرحبا", false);
    show(LANGS.map(function (name, i) { return [name, function () { LANG = i; $("ask-panel").dir = (i === 3 ? "rtl" : "ltr"); menu(); }]; }));
  };
  // Typing also works: a phone number during the distress flow, or keywords
  var KEYS = [["agency|licen|verify|register", agency], ["scam|fake|paid|fraud", scam], ["contract|right|passport|salary", rights], ["help|danger|emergency|abuse|abroad|trapped", abroad]];
  form.addEventListener("submit", function (e) {
    e.preventDefault();
    var q = input.value.trim(); if (!q) return;
    input.value = ""; add(q, true);
    if (STATE === "num") {
      var n = q.replace(/\D/g, "");
      if (n.length < 9) { say(tx("q_bad")); return; }
      NUM = n; STATE = ""; say(tx("q_loc"));
      show([[tx("o_yes"), function () { send(true); }], [tx("o_no"), function () { send(false); }]]);
      return;
    }
    var hit = null, t = q.toLowerCase();
    KEYS.forEach(function (k) { if (!hit && new RegExp(k[0]).test(t)) hit = k[1]; });
    if (hit) { hit(); } else { say(tx("free")); menu(); }
  });
  var Rec = window.SpeechRecognition || window.webkitSpeechRecognition, mic = $("chat-mic");
  if (!Rec) { mic.hidden = true; } else {
    mic.onclick = function () {
      var r = new Rec(); r.lang = VOICE[LANG];
      r.onresult = function (e) { input.value = e.results[0][0].transcript; form.requestSubmit(); };
      r.start();
    };
  }
}

// J. Open or close the Ask Safe Passage panel (on every page)
function toggleAsk(force) {
  var p = $("ask-panel");
  var show = (force === undefined) ? p.hidden : force;
  p.hidden = !show;
  $("ask-btn").setAttribute("aria-expanded", show);
  if (show) { if (window.startChat) { startChat(); } $("chat-input").focus(); }
}

// K. Safety passport: remember visited pages and stamp them
function stamps() {
  var list = $("stamps"); if (!list) return;
  var cur = document.querySelector(".sheet").dataset.page, seen = [];
  try { seen = JSON.parse(localStorage.getItem("sk_seen") || "[]"); } catch (e) { seen = []; }
  if (seen.indexOf(cur) < 0) {
    seen.push(cur);
    try { localStorage.setItem("sk_seen", JSON.stringify(seen)); } catch (e) { }
  }
  var n = 0;
  list.querySelectorAll("li").forEach(function (li) {
    var on = seen.indexOf(li.dataset.page) > -1;
    li.classList.toggle("on", on);
    if (on) n++;
  });
  $("stamp-count").textContent = n + " of 7 stamps collected" + (n === 7 ? ". Cleared for departure!" : "");
}

// L. Start everything when the page is ready
document.addEventListener("DOMContentLoaded", init);
window.SK = { init: init };
